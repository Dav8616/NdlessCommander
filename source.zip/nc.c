    #include "nc.h"

    /* Globals */
    SDL_Surface *screen = NULL;
    nSDL_Font *font_white = NULL, *font_black = NULL, *font_blue = NULL, *font_green = NULL, *font_grey = NULL;
    SDL_bool done = SDL_FALSE;
    SortMode sort_mode = SORT_NAME;
    int active_pane = 0;
    Pane panes[2];

    /* ---------- Helpers ---------- */

    static int endswith_ci(const char *s, const char *suffix) {
        size_t ls = strlen(s), lf = strlen(suffix);
        if (lf > ls) return 0;
        const char *a = s + (ls - lf);
        for (size_t i = 0; i < lf; ++i) {
            char c1 = a[i], c2 = suffix[i];
            if (c1 >= 'A' && c1 <= 'Z') c1 += 32;
            if (c2 >= 'A' && c2 <= 'Z') c2 += 32;
            if (c1 != c2) return 0;
        }
        return 1;
    }

    /* Initialize app, fonts, panes */
    void app_init(void) {
        if (SDL_Init(SDL_INIT_VIDEO) == -1) {
            printf("SDL init failed: %s\n", SDL_GetError());
            exit(EXIT_FAILURE);
        }

        screen = SDL_SetVideoMode(SCREEN_W, SCREEN_H, has_colors ? 16 : 8, SDL_SWSURFACE);
        if (!screen) {
            printf("Video mode failed: %s\n", SDL_GetError());
            SDL_Quit();
            exit(EXIT_FAILURE);
        }

        font_white = nSDL_LoadFont(NSDL_FONT_TINYTYPE, 255, 255, 255);
        font_black = nSDL_LoadFont(NSDL_FONT_TINYTYPE, 0, 0, 0);
        font_blue  = nSDL_LoadFont(NSDL_FONT_TINYTYPE, 0, 128, 255);
        font_green = nSDL_LoadFont(NSDL_FONT_TINYTYPE, 0, 170, 0);
        font_grey  = nSDL_LoadFont(NSDL_FONT_TINYTYPE, 96, 96, 96);

        if (!font_white || !font_black || !font_blue || !font_green || !font_grey) {
            printf("Font load failed\n");
            app_quit();
            exit(EXIT_FAILURE);
        }

        SDL_EnableKeyRepeat(400, 150);

        // init panes to \documents if available, else A:
        for (int i = 0; i < 2; ++i) {
            panes[i].cwd[0] = '\0';
            if (NU_Set_Current_Dir("\\documents") == 0) {
                 NU_Current_Dir("A:", panes[i].cwd);
            } else {
                 NU_Set_Current_Dir("A:");
                 NU_Current_Dir("A:", panes[i].cwd);
            }
            panes[i].count = panes[i].choice = panes[i].scroll = panes[i].preview_scroll = 0;
            scan_dir(&panes[i]);
        }

        active_pane = 0;

        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 255, 255, 255));
        draw_ui();
        SDL_Flip(screen);
    }

    void app_quit(void) {
        if (font_white) nSDL_FreeFont(font_white);
        if (font_black) nSDL_FreeFont(font_black);
        if (font_blue)  nSDL_FreeFont(font_blue);
        if (font_green) nSDL_FreeFont(font_green);
        if (font_grey)  nSDL_FreeFont(font_grey);
        SDL_Quit();
    }

    /* --------- Filesystem helpers ---------- */

    static int stat_joined(const char *dir, const char *name, struct stat *st) {
        char full[BUF_SIZE];
        path_join(full, sizeof(full), dir, name);
        return stat(full, st);
    }

    void scan_dir(Pane *p) {
        int prev_choice = p->choice;
        NU_Set_Current_Dir(p->cwd);

        p->count = 0;
        p->choice = 0;
        p->scroll = 0;
        p->preview_scroll = 0;

        struct dstat info;
        if (NU_Get_First(&info, "*.*") == 0) {
            do {
                 if (p->count >= MAX_FILES) break;
                 FileEntry *e = &p->files[p->count];
                 strncpy(e->name, info.filepath, sizeof(e->name)-1);
                 e->name[sizeof(e->name)-1] = '\0';
                 struct stat st;
                 if (stat_joined(p->cwd, e->name, &st) == 0) {
                     e->is_dir = S_ISDIR(st.st_mode) ? 1 : 0;
                     e->size   = (long long)st.st_size;
                     e->mtime  = st.st_mtim.tv_sec;
                 } else {
                     e->is_dir = 0; e->size = 0; e->mtime = 0;
                 }
                 e->selected = 0;
                 p->count++;
            } while (NU_Get_Next(&info) == 0);
            NU_Done(&info);
        }
        sort_files(p);
        if (prev_choice >= 0 && prev_choice < p->count) {
            p->choice = prev_choice;
            ensure_choice_visible(p);
        }
    }

    void ensure_choice_visible(Pane *p) {
        if (p->choice < 0) p->choice = 0;
        if (p->choice >= p->count) p->choice = p->count ? p->count - 1 : 0;
        if (p->choice < p->scroll) p->scroll = p->choice;
        if (p->choice >= p->scroll + NUM_ITEMS_SHOWN) p->scroll = p->choice - (NUM_ITEMS_SHOWN - 1);
        if (p->scroll < 0) p->scroll = 0;
    }

    int path_join(char *out, size_t outsz, const char *dir, const char *name) {
        size_t ld = strlen(dir);
        int need_sep = (ld > 0 && dir[ld-1] != '\\');
        int n = snprintf(out, outsz, "%s%s%s", dir, need_sep ? "\\" : "", name);
        return (n > 0 && (size_t)n < outsz) ? 0 : -1;
    }

    int is_text_like(const char *name) {
        return endswith_ci(name, ".txt") || endswith_ci(name, ".log") || endswith_ci(name, ".cfg") ||
                endswith_ci(name, ".ini") || endswith_ci(name, ".c") || endswith_ci(name, ".h") ||
                endswith_ci(name, ".lua") || endswith_ci(name, ".asm") || endswith_ci(name, ".sh");
    }

    int is_exec_like(const char *name) {
        return endswith_ci(name, ".tns") || endswith_ci(name, ".ndz") || endswith_ci(name, ".ndless");
    }

    int safe_mkdir(const char *path) {
        return mkdir(path, 0777);
    }

    /* ---------- Sorting ---------- */

    int cmp_entries(const void *a, const void *b) {
        const FileEntry *ea = (const FileEntry *)a;
        const FileEntry *eb = (const FileEntry *)b;

        if (ea->is_dir != eb->is_dir) return eb->is_dir - ea->is_dir;

        switch (sort_mode) {
            case SORT_SIZE:
                 if (ea->size < eb->size) return -1;
                 if (ea->size > eb->size) return 1;
                 break;
            case SORT_DATE:
                 if (ea->mtime < eb->mtime) return -1;
                 if (ea->mtime > eb->mtime) return 1;
                 break;
            case SORT_NAME:
            default:
                 break;
        }
        return strcasecmp(ea->name, eb->name);
    }

    void sort_files(Pane *p) {
        if (p->count > 1) qsort(p->files, p->count, sizeof(FileEntry), cmp_entries);
    }

    /* ---------- UI ---------- */

    void draw_header_footer(void) {
        SDL_Rect r;
        r.x = 0; r.y = 0; r.w = SCREEN_W; r.h = HEADER_H; DRAW_RECT(r);
        r.x = 0; r.y = SCREEN_H - FOOTER_H; r.w = SCREEN_W; r.h = FOOTER_H; DRAW_RECT(r);

        nSDL_DrawString(screen, font_white, 8, 8, "Ndless Commander " VERSION);
        const char *sm = (sort_mode == SORT_NAME) ? "Name" : (sort_mode == SORT_SIZE) ? "Size" : "Date";
        char smbuf[32];
        snprintf(smbuf, sizeof(smbuf), "[Sort: %s]", sm);
        int sw = nSDL_GetStringWidth(font_white, smbuf);
        nSDL_DrawString(screen, font_white, SCREEN_W - sw - 8, 8, smbuf);

        nSDL_DrawString(screen, font_white, 8, SCREEN_H - FOOTER_H + 8,
            "Arrows: Nav  Enter: Open  Tab: Switch  Space: Select  ?: Help  Menu: Functions");
    }

    void draw_status(const char *msg) {
        int w = nSDL_GetStringWidth(font_white, msg);
        int x = SCREEN_W - w - 8;
        int y = SCREEN_H - FOOTER_H + 8;
        SDL_Rect r = { x - 4, y - 2, w + 8, 12 };
        SDL_FillRect(screen, &r, SDL_MapRGB(screen->format, 255, 255, 255));
        nSDL_DrawString(screen, font_black, x, y, msg);
    }

    void draw_pane(int idx) {
        Pane *p = &panes[idx];
        int x0 = idx == 0 ? 0 : PANE_W;
        SDL_Rect r;
        r.x = x0; r.y = 0; r.w = 1; r.h = SCREEN_H; DRAW_RECT(r);
        r.x = x0 + PANE_W - 1; r.y = 0; r.w = 1; r.h = SCREEN_H; DRAW_RECT(r);

        DRAW_STRING_BOLD(font_white, x0 + 8, HEADER_H + 8, "Name");

        int cy = SCREEN_H - FOOTER_H + 8;
        int cw = nSDL_GetStringWidth(font_white, p->cwd);
        int cx = x0 + 8;
        if (idx == 1 && cx + cw >= x0 + PANE_W - 4) {
            const char *s = p->cwd;
            while (nSDL_GetStringWidth(font_white, s) > PANE_W - 16) ++s;
            nSDL_DrawString(screen, font_white, cx, cy, s);
        } else {
            nSDL_DrawString(screen, font_white, cx, cy, p->cwd);
        }

        int row_y = LIST_TOP;
        int last = p->scroll + NUM_ITEMS_SHOWN;
        if (last > p->count) last = p->count;
        for (int i = p->scroll; i < last; ++i) {
            FileEntry *e = &p->files[i];

            if (i == p->choice && idx == active_pane) {
                 SDL_Rect hl = { x0 + 2, row_y - 1, PANE_W - 4, ROW_H + 2 };
                 SDL_FillRect(screen, &hl, SDL_MapRGB(screen->format, 200, 32, 32));
            }

            if (e->selected) {
                 nSDL_DrawString(screen, (i == p->choice && idx == active_pane) ? font_white : font_black,
                                  x0 + 4, row_y, "*");
            }

            nSDL_Font *f =
                 (i == p->choice && idx == active_pane) ? font_white :
                 (e->is_dir ? font_blue :
                 (is_exec_like(e->name) ? font_green : font_grey));

            nSDL_DrawString(screen, f, x0 + 12, row_y, e->name);

            if (e->is_dir && strcmp(e->name, ".") && strcmp(e->name, ".."))
                 nSDL_DrawString(screen, f, x0 + 4, row_y, "\\");

            row_y += ROW_H;
        }
    }

    static void draw_text_preview_box(const char *text, int x, int y, int w, int h) {
        SDL_Rect box = { x, y, w, h };
        SDL_FillRect(screen, &box, SDL_MapRGB(screen->format, 255, 255, 255));
        SDL_Rect b1 = { x, y, w, 1 }, b2 = { x, y + h - 1, w, 1 };
        SDL_Rect b3 = { x, y, 1, h }, b4 = { x + w - 1, y, 1, h };
        DRAW_RECT(b1); DRAW_RECT(b2); DRAW_RECT(b3); DRAW_RECT(b4);

        const int max_cols = 25;
        int cx = x + 4, cy = y + 4;
        const char *p = text;
        char line[64];
        int col = 0, li = 0;
        while (*p && cy + ROW_H + 2 < y + h) {
            char c = *p++;
            if (c == '\n' || col >= max_cols) {
                 line[li] = '\0';
                 nSDL_DrawString(screen, font_black, cx, cy, line);
                 cy += ROW_H;
                 col = 0; li = 0;
                 if (c == '\n') continue;
            }
            if (li < (int)sizeof(line) - 1) line[li++] = c;
            col++;
        }
        if (li > 0 && cy + ROW_H + 2 < y + h) {
            line[li] = '\0';
            nSDL_DrawString(screen, font_black, cx, cy, line);
        }
    }

    void draw_file_info(void) {
        Pane *p = &panes[active_pane];
        if (p->count == 0) return;
        FileEntry *e = &p->files[p->choice];

        int info_x = (active_pane == 0) ? PANE_W : 0;
        int info_w = PANE_W;

        DRAW_STRING_BOLD(font_white, info_x + 8, HEADER_H + 8, "File:");
        nSDL_DrawString(screen, font_white, info_x + 44, HEADER_H + 8, e->name);

        DRAW_STRING_BOLD(font_white, info_x + 8, HEADER_H + 16, "Size:");
        char sbuf[64];
        readable_size(e->size, sbuf, sizeof(sbuf));
        nSDL_DrawString(screen, font_white, info_x + 44, HEADER_H + 16, e->is_dir ? "DIR" : sbuf);

        int px = info_x + 4, py = 72, pw = info_w - 8, ph = 137;

        if (!e->is_dir && is_text_like(e->name)) {
            char full[BUF_SIZE];
            path_join(full, sizeof(full), p->cwd, e->name);
            FILE *fp = fopen(full, "r");
            if (fp) {
                 static char buf[BIG_BUF_SIZE];
                 int skip = p->preview_scroll;
                 if (skip > 0) fseek(fp, skip, SEEK_SET);
                 size_t r = fread(buf, 1, sizeof(buf) - 1, fp);
                 buf[r] = '\0';
                 fclose(fp);
                 draw_text_preview_box(buf, px, py, pw, ph);
                 nSDL_DrawString(screen, font_grey, info_x + 8, py + ph + 2, "[ use [ and ] to scroll preview ]");
            } else {
                 draw_text_preview_box("Cannot open file.", px, py, pw, ph);
            }
        } else {
            SDL_Rect box = { px, py, pw, ph };
            SDL_FillRect(screen, &box, SDL_MapRGB(screen->format, 255, 255, 255));
            SDL_Rect b1 = { px, py, pw, 1 }, b2 = { px, py + ph - 1, pw, 1 };
            SDL_Rect b3 = { px, py, 1, ph }, b4 = { px + pw - 1, py, 1, ph };
            DRAW_RECT(b1); DRAW_RECT(b2); DRAW_RECT(b3); DRAW_RECT(b4);
            nSDL_DrawString(screen, font_black, info_x + 8, py + 4, e->is_dir ? "No preview (directory)" : "No preview");
        }
    }

    void draw_help_overlay(void) {
        const char *lines[] = {
            "Keybinds",
            "----------",
            "Arrows         Navigate",
            "Enter          Open dir",
            "Tab            Switch pane",
            "Space          Select/unselect",
            "S              Toggle sort (Name/Size/Date)",
            "R              Rename",
            "N              New folder",
            "[ / ]          Preview scroll",
            "Menu           Functions menu",
            "Esc            Quit",
            NULL
        };
        SDL_Rect box = { 24, 24, SCREEN_W - 48, SCREEN_H - 48 };
        SDL_FillRect(screen, &box, SDL_MapRGB(screen->format, 255, 255, 255));
        SDL_Rect b1 = { box.x, box.y, box.w, 1 }, b2 = { box.x, box.y + box.h - 1, box.w, 1 };
        SDL_Rect b3 = { box.x, box.y, 1, box.h }, b4 = { box.x + box.w - 1, box.y, 1, box.h };
        DRAW_RECT(b1); DRAW_RECT(b2); DRAW_RECT(b3); DRAW_RECT(b4);

        int y = box.y + 8;
        for (int i = 0; lines[i]; ++i, y += ROW_H + 2) {
            nSDL_DrawString(screen, font_black, box.x + 8, y, lines[i]);
        }
        SDL_Flip(screen);

        SDL_Event e;
        while (SDL_WaitEvent(&e)) {
            if (e.type == SDL_KEYDOWN) break;
        }
    }

    /* ----------- Functions Menu Overlay ----------- */

    void draw_functions_menu(void) {
        const char *lines[] = {
            "Available Functions",
            "-------------------",
            "Navigate            Arrows",
            "Open Directory      Enter",
            "Switch Pane         Tab",
            "Select/Unselect     Space",
            "Toggle Sort         S",
            "Rename              R",
            "New Folder          N",
            "Preview Scroll      [ / ]",
            "Show Help           ?",
            "Quit                Esc",
            NULL
        };
        SDL_Rect box = { 32, 32, SCREEN_W - 64, SCREEN_H - 64 };
        SDL_FillRect(screen, &box, SDL_MapRGB(screen->format, 255, 255, 255));
        SDL_Rect b1 = { box.x, box.y, box.w, 1 }, b2 = { box.x, box.y + box.h - 1, box.w, 1 };
        SDL_Rect b3 = { box.x, box.y, 1, box.h }, b4 = { box.x + box.w - 1, box.y, 1, box.h };
        DRAW_RECT(b1); DRAW_RECT(b2); DRAW_RECT(b3); DRAW_RECT(b4);

        DRAW_STRING_BOLD(font_black, box.x + 8, box.y + 8, "Functions Menu");
        int y = box.y + 28;
        for (int i = 1; lines[i]; ++i, y += ROW_H + 2) {
            nSDL_DrawString(screen, font_black, box.x + 8, y, lines[i]);
        }
        nSDL_DrawString(screen, font_grey, box.x + 8, box.y + box.h - 20, "[Press any key to close]");
        SDL_Flip(screen);

        SDL_Event e;
        while (SDL_WaitEvent(&e)) {
            if (e.type == SDL_KEYDOWN) break;
        }
    }

    void draw_ui(void) {
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 255, 255, 255));
        draw_header_footer();
        draw_pane(0);
        draw_pane(1);
        draw_file_info();
    }

    /* ---------- selection helpers ---------- */

    void toggle_selection(Pane *p) {
        if (p->count == 0) return;
        FileEntry *e = &p->files[p->choice];
        if (strcmp(e->name, ".") == 0 || strcmp(e->name, "..") == 0) return;
        e->selected = !e->selected;
    }

    void clear_selections(Pane *p) {
        for (int i = 0; i < p->count; ++i) p->files[i].selected = 0;
    }

    int count_selected(const Pane *p) {
        int c = 0;
        for (int i = 0; i < p->count; ++i) if (p->files[i].selected) ++c;
        return c;
    }

    /* ---------- Actions (rename/mkdir) ---------- */

    void enter_dir_or_open(Pane *p) {
        if (p->count == 0) return;
        FileEntry *e = &p->files[p->choice];
        if (!e->is_dir) return;
        if (strcmp(e->name, ".") == 0) return;
        if (strcmp(e->name, "..") == 0) {
            char *bs = strrchr(p->cwd, '\\');
            if (bs && bs != p->cwd) *bs = '\0';
            else strcpy(p->cwd, "A:");
        } else {
            char newcwd[BUF_SIZE];
            if (path_join(newcwd, sizeof(newcwd), p->cwd, e->name) != 0) return;
            strncpy(p->cwd, newcwd, sizeof(p->cwd)-1);
            p->cwd[sizeof(p->cwd)-1] = '\0';
        }
        scan_dir(p);
    }

    int rename_item(Pane *p) {
        if (p->count == 0) return -1;
        FileEntry *e = &p->files[p->choice];
        if (strcmp(e->name, ".") == 0 || strcmp(e->name, "..") == 0) return -1;

        char newname[BUF_SIZE];
        strncpy(newname, e->name, sizeof(newname)-1);
        newname[sizeof(newname)-1] = '\0';

        if (!popup_input("Rename", "New name:", newname, sizeof(newname))) return -1;

        char oldpath[BUF_SIZE], newpath[BUF_SIZE];
        path_join(oldpath, sizeof(oldpath), p->cwd, e->name);
        path_join(newpath, sizeof(newpath), p->cwd, newname);

        if (rename(oldpath, newpath) != 0) {
            draw_status("Rename failed");
            return -1;
        }
        scan_dir(p);
        draw_status("Renamed");
        return 0;
    }

    int make_folder(Pane *p) {
        char name[BUF_SIZE] = "New Folder";
        if (!popup_input("New Folder", "Folder name:", name, sizeof(name))) return -1;
        char full[BUF_SIZE];
        path_join(full, sizeof(full), p->cwd, name);
        if (safe_mkdir(full) != 0) {
            draw_status("mkdir failed");
            return -1;
        }
        scan_dir(p);
        draw_status("Folder created");
        return 0;
    }

    /* ---------- Popups ---------- */

    int popup_confirm(const char *title, const char *question, const char *btn_no, const char *btn_yes) {
        int w = 260, h = 64;
        SDL_Rect box = { (SCREEN_W - w)/2, (SCREEN_H - h)/2, w, h };
        SDL_FillRect(screen, &box, SDL_MapRGB(screen->format, 255, 255, 255));
        SDL_Rect b1 = { box.x, box.y, box.w, 1 }, b2 = { box.x, box.y + box.h - 1, box.w, 1 };
        SDL_Rect b3 = { box.x, box.y, 1, box.h }, b4 = { box.x + box.w - 1, box.y, 1, box.h };
        DRAW_RECT(b1); DRAW_RECT(b2); DRAW_RECT(b3); DRAW_RECT(b4);

        DRAW_STRING_BOLD(font_black, box.x + 8, box.y + 6, title);
        nSDL_DrawString(screen, font_black, box.x + 8, box.y + 22, question);

        char btns[64];
        snprintf(btns, sizeof(btns), "[%s]   [%s]", btn_no, btn_yes);
        int bw = nSDL_GetStringWidth(font_black, btns);
        nSDL_DrawString(screen, font_black, box.x + (box.w - bw)/2, box.y + h - 16, btns);
        SDL_Flip(screen);

        int yes = 0;
        SDL_Event e;
        while (SDL_WaitEvent(&e)) {
            if (e.type != SDL_KEYDOWN) continue;
            if (e.key.keysym.sym == SDLK_LEFT || e.key.keysym.sym == SDLK_RIGHT) yes ^= 1;
            else if (e.key.keysym.sym == SDLK_RETURN) return yes ? 1 : 0;
            else if (e.key.keysym.sym == SDLK_ESCAPE) return 0;
        }
        return 0;
    }

    int popup_input(const char *title, const char *prompt, char *buf, size_t bufsz) {
        int w = 280, h = 84;
        SDL_Rect box = { (SCREEN_W - w)/2, (SCREEN_H - h)/2, w, h };

        for (;;) {
            SDL_FillRect(screen, &box, SDL_MapRGB(screen->format, 255, 255, 255));
            SDL_Rect b1 = { box.x, box.y, box.w, 1 }, b2 = { box.x, box.y + box.h - 1, box.w, 1 };
            SDL_Rect b3 = { box.x, box.y, 1, box.h }, b4 = { box.x + box.w - 1, box.y, 1, box.h };
            DRAW_RECT(b1); DRAW_RECT(b2); DRAW_RECT(b3); DRAW_RECT(b4);

            DRAW_STRING_BOLD(font_black, box.x + 8, box.y + 6, title);
            nSDL_DrawString(screen, font_black, box.x + 8, box.y + 22, prompt);

            SDL_Rect in = { box.x + 8, box.y + 38, box.w - 16, 16 };
            SDL_FillRect(screen, &in, SDL_MapRGB(screen->format, 240, 240, 240));
            nSDL_DrawString(screen, font_black, in.x + 2, in.y + 2, buf);

            nSDL_DrawString(screen, font_grey, box.x + 8, box.y + h - 16, "[Enter=OK]  [Esc=Cancel]");

            SDL_Flip(screen);

            SDL_Event e;
            if (!SDL_WaitEvent(&e)) continue;
            if (e.type != SDL_KEYDOWN) continue;

            SDLKey k = e.key.keysym.sym;
            if (k == SDLK_RETURN) return 1;
            if (k == SDLK_ESCAPE) return 0;
            if (k == SDLK_BACKSPACE) {
                 size_t l = strlen(buf);
                 if (l > 0) buf[l-1] = '\0';
            } else {
                 char c = (char)e.key.keysym.sym;
                 if (c >= 32 && c < 127) {
                     size_t l = strlen(buf);
                     if (l + 1 < bufsz) { buf[l] = c; buf[l+1] = '\0'; }
                 }
            }
        }
    }

    /* ---------- utilities ---------- */

    char *readable_size(long long size, char *buffer, size_t bufsz) {
        const char *units[] = { "B", "kB", "MB", "GB" };
        int u = 0;
        double s = (double)size;
        while (s >= 1024.0 && u < 3) { s /= 1024.0; ++u; }
        snprintf(buffer, bufsz, (s < 10 && u > 0) ? "%.1f%s" : "%.0f%s", s, units[u]);
        return buffer;
    }

    /* ---------- input handling ---------- */

    void handle_keydown(SDLKey key) {
        Pane *p = &panes[active_pane];

        switch (key) {
            case SDLK_UP:
                 if (p->choice > 0) p->choice--;
                 ensure_choice_visible(p);
                 break;
            case SDLK_DOWN:
                 if (p->choice + 1 < p->count) p->choice++;
                 ensure_choice_visible(p);
                 break;
            case SDLK_PAGEUP:
                 p->choice -= NUM_ITEMS_SHOWN;
                 if (p->choice < 0) p->choice = 0;
                 ensure_choice_visible(p);
                 break;
            case SDLK_PAGEDOWN:
                 p->choice += NUM_ITEMS_SHOWN;
                 if (p->choice >= p->count) p->choice = p->count - 1;
                 ensure_choice_visible(p);
                 break;
            case SDLK_LEFT:
                 active_pane = 0;
                 break;
            case SDLK_RIGHT:
                 active_pane = 1;
                 break;
            case SDLK_TAB:
                 active_pane ^= 1;
                 break;
            case SDLK_RETURN:
                 enter_dir_or_open(p);
                 break;
            case SDLK_SPACE:
                 toggle_selection(p);
                 if (p->choice + 1 < p->count) { p->choice++; ensure_choice_visible(p); }
                 break;
            case SDLK_s:
                 sort_mode = (SortMode)((((int)sort_mode) + 1) % 3);
                 sort_files(p);
                 ensure_choice_visible(p);
                 draw_status("Sort toggled");
                 break;
            case SDLK_r:
                 rename_item(p);
                 break;
            case SDLK_n:
                 make_folder(p);
                 break;
            case SDLK_LEFTBRACKET:
                 if (p->preview_scroll > 0) p->preview_scroll -= 256;
                 if (p->preview_scroll < 0) p->preview_scroll = 0;
                 break;
            case SDLK_RIGHTBRACKET:
                 p->preview_scroll += 256;
                 break;
            case SDLK_SLASH:
            case SDLK_QUESTION:
                 draw_help_overlay();
                 break;
            case SDLK_MENU: // Add menu key handler
                 draw_functions_menu();
                 break;
            case SDLK_ESCAPE:
                 done = SDL_TRUE;
                 break;
            default:
                 break;
        }
    }

    /* ---------- main ---------- */

    int main(void) {
        app_init();

        while (!done) {
            draw_ui();
            SDL_Flip(screen);

            SDL_Event event;
            SDL_WaitEvent(&event);
            if (event.type == SDL_KEYDOWN) handle_keydown(event.key.keysym.sym);
        }

        app_quit();
        return EXIT_SUCCESS;
    }

#ifndef NC_H
#define NC_H

#include <os.h>
#include <SDL/SDL.h>
#include <sys/stat.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define VERSION "0.6"

#define SCREEN_W 320
#define SCREEN_H 240

#define PANE_W   160
#define PANE_H   240

#define HEADER_H 24
#define FOOTER_H 24
#define LIST_TOP 32
#define ROW_H    8

#define NUM_ITEMS_SHOWN ((SCREEN_H - HEADER_H - FOOTER_H - (LIST_TOP - HEADER_H)) / ROW_H)  // typically 18

#define BUF_SIZE    512
#define BIG_BUF_SIZE 1024

#define MAX_FILES   256
#define MAX_SELECT  MAX_FILES

// Panel color
#define COLOR_PANEL_R 64
#define COLOR_PANEL_G 0
#define COLOR_PANEL_B 0

// Drawing helpers
#define DRAW_RECT(rect) SDL_FillRect(screen, &(rect), SDL_MapRGB(screen->format, COLOR_PANEL_R, COLOR_PANEL_G, COLOR_PANEL_B))

// Bold text (1px offset shadow)
#define DRAW_STRING_BOLD(font, x, y, s) do { \
    nSDL_DrawString(screen, font, (x)+1, (y), s); \
    nSDL_DrawString(screen, font, (x), (y), s); \
} while (0)

typedef enum {
    SORT_NAME = 0,
    SORT_SIZE = 1,
    SORT_DATE = 2,
} SortMode;

typedef struct {
    char name[BUF_SIZE];
    int is_dir;
    long long size;
    time_t mtime;
    int selected;
} FileEntry;

typedef struct {
    char cwd[BUF_SIZE];
    FileEntry files[MAX_FILES];
    int count;
    int choice;
    int scroll;
    int preview_scroll;
} Pane;

/* globals (defined in nc.c) */
extern SDL_Surface *screen;
extern nSDL_Font *font_white;
extern nSDL_Font *font_black;
extern nSDL_Font *font_blue;
extern nSDL_Font *font_green;
extern nSDL_Font *font_grey;

extern SDL_bool done;
extern SortMode sort_mode;
extern int active_pane;
extern Pane panes[2];

/* API */
void app_init(void);
void app_quit(void);

void draw_ui(void);
void draw_header_footer(void);
void draw_pane(int idx);
void draw_file_info(void);
void draw_status(const char *msg);
void draw_progress(const char *label, int step, int total);

void scan_dir(Pane *p);
void ensure_choice_visible(Pane *p);
int  is_text_like(const char *name);
int  is_exec_like(const char *name);
int  safe_copy_file(const char *src, const char *dst, long long *bytes_copied); // returns 0 on success, nonzero on error
int  safe_move_file(const char *src, const char *dst); // returns 0 on success, nonzero on error
int  safe_remove_path(const char *path); // returns 0 on success, nonzero on error
int  safe_mkdir(const char *path);
int  path_join(char *out, size_t outsz, const char *dir, const char *name);

void toggle_selection(Pane *p);
void clear_selections(Pane *p);
int  count_selected(const Pane *p);

void sort_files(Pane *p);
int  cmp_entries(const void *a, const void *b);

void handle_keydown(SDLKey key);
void enter_dir_or_open(Pane *p);
int  rename_item(Pane *p);
int  make_folder(Pane *p);
int  batch_copy_move(int do_move);
int  batch_delete(void);

int  popup_confirm(const char *title, const char *question, const char *btn_no, const char *btn_yes);
int  popup_input(const char *title, const char *prompt, char *buf, size_t bufsz);

char *readable_size(long long size, char *buffer, size_t bufsz);

#endif // NC_H